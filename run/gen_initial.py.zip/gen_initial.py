import torch
import numpy as np
import os
import scipy.ndimage

def shift_h(F, T):
    irf = np.zeros(T)
    irf[0:len(F)] = F
    irf = irf / np.sum(irf)
    attack = irf.argmax() + 1

    h = np.roll(irf, -attack)
    h1 = np.flipud(h).copy()
    return h1

# def conv3d_separate2(inp, K):
#     # inp shape: [4, 1, T, H, W]
#     w3 = torch.ones(1, 1, K, 1, 1) / K
#     inp = torch.nn.functional.conv3d(inp, w3.to(inp.device), padding="same")

#     L, _, T, H, W = inp.shape
#     inp = inp.reshape([L, T, H, W])  # [4 x TH x W]
#     w2 = torch.ones(T, 1, K, 1) / K
#     inp = torch.nn.functional.conv2d(inp, w2.to(inp.device), padding="same", groups=T)
#     w2 = torch.ones(T, 1, 1, K) / K
#     inp = torch.nn.functional.conv2d(inp, w2.to(inp.device), padding="same", groups=T)
    
#     return inp.reshape(L, 1, T, H, W)

def conv3d_separate(inp, K):
    # if K < 10:
    w3 = torch.ones(1, 1, K, 1, 1) / K
    inp = torch.nn.functional.conv3d(inp, w3.to(inp.device), padding="same")
    w3 = torch.ones(1, 1, 1, K, 1) / K
    inp = torch.nn.functional.conv3d(inp, w3.to(inp.device), padding="same")
    w3 = torch.ones(1, 1, 1, 1, K) / K
    return torch.nn.functional.conv3d(inp, w3.to(inp.device), padding="same")
    
    # else: # memory-saving mode
    # for i in range(inp.shape[0]):
    #     w3 = torch.ones(1, 1, K, 1, 1) / K
    #     inp[i:i+1,:] = torch.nn.functional.conv3d(inp[i:i+1,:], w3.to(inp.device), padding="same")
    #     w3 = torch.ones(1, 1, 1, K, 1) / K
    #     inp[i:i+1,:] = torch.nn.functional.conv3d(inp[i:i+1,:], w3.to(inp.device), padding="same")
    #     w3 = torch.ones(1, 1, 1, 1, K) / K
    #     inp[i:i+1,:] = torch.nn.functional.conv3d(inp[i:i+1,:], w3.to(inp.device), padding="same")
    
    return inp


def conv3d_separate_cpu(inp, K):
    inp_np = inp.numpy()
    w = np.ones(K) / K
    inp_np = scipy.ndimage.convolve1d(inp_np, w, axis=2, mode='nearest')
    inp_np = scipy.ndimage.convolve1d(inp_np, w, axis=3, mode='nearest')
    inp_np = scipy.ndimage.convolve1d(inp_np, w, axis=4, mode='nearest')
    return torch.tensor(inp_np)
    
def conv2d(inp, K):
    if inp.device == torch.device('cpu'):
        inp_np = inp.numpy()
        w = np.ones(K) / K

        inp_np = scipy.ndimage.convolve1d(inp_np, w, axis=2, mode='nearest')
        inp_np = scipy.ndimage.convolve1d(inp_np, w, axis=3, mode='nearest')
        return torch.tensor(inp_np)

    else:
        w2 = torch.ones(1, 1, K, 1) / K
        inp1 = torch.nn.functional.conv2d(inp, w2.to(inp.device), padding="same")
        w2 = torch.ones(1, 1, 1, K) / K
        return torch.nn.functional.conv2d(inp1, w2.to(inp.device), padding="same")

def gen_initial_multiscale(tof, h1, nscale, KK=[1,3,7,13], use_cuda=None):
    if len(h1.shape) != 1:
        assert 0, "IRF should have be of 1D"
    if len(tof.shape) != 3:
        assert 0, "ToF shape should be of [height x width x time bin]"

    if use_cuda == None:
        use_cuda = 1 if torch.cuda.is_available() else 0

    KK = np.array(KK)
    KKhalf = KK // 2

    H, W, T = tof.shape
        
    if use_cuda == 1:
        device = torch.device('cuda')
    else:
        device = torch.device('cpu')
        print("CPU mode is used and it will take several minutes (<= 4 minutes), depending on the data.")

    # print("before use fft")

    #----------------- 1. cross correlation of histogram with IRF
    tof_NxT = tof.reshape(tof.shape[0]*tof.shape[1], tof.shape[2])
    tof_irf = torch.real(torch.fft.ifft( torch.fft.fft(tof_NxT.to(device), dim=1) * torch.fft.fft(h1.to(device)), dim=1))
    tof_Tx1xHxW = tof_irf.transpose(0,1).reshape(T, 1, H, W)
    
    # tof_NxT = tof_NxT.cpu()

    del tof_irf
    torch.cuda.empty_cache()

    # print("before spatial sampling")
    #----------------- 2. spatial downsampling
    # if use_cuda:
    #     w1 = torch.zeros(3, 1, KK[-1], KK[-1])  # outputs 3 channels
    #     w1[0, :, KKhalf[-1]-KKhalf[1] : KKhalf[-1]+KKhalf[1]+1, KKhalf[-1]-KKhalf[1] : KKhalf[-1]+KKhalf[1]+1] = 1 / (KK[1]*KK[1])
    #     w1[1, :, KKhalf[-1]-KKhalf[2] : KKhalf[-1]+KKhalf[2]+1, KKhalf[-1]-KKhalf[2] : KKhalf[-1]+KKhalf[2]+1] = 1 / (KK[2]*KK[2])
    #     w1[2, :, KKhalf[-1]-KKhalf[3] : KKhalf[-1]+KKhalf[3]+1, KKhalf[-1]-KKhalf[3] : KKhalf[-1]+KKhalf[3]+1] = 1 / (KK[3]*KK[3])
    #     tof_conv2d = torch.nn.functional.conv2d(tof_Tx1xHxW, w1.to(device), padding="same")
    # else:
    #     tof1 = conv2d(tof_Tx1xHxW, KK[1])
    #     tof2 = conv2d(tof_Tx1xHxW, KK[2])
    #     tof3 = conv2d(tof_Tx1xHxW, KK[3])
    #     tof_conv2d = torch.cat([tof1, tof2, tof3], dim=1)
    #     del tof1, tof2, tof3
    # tof_conv[1:4, :] = tof_conv2d.transpose(0, 1).reshape(3, 1, -1, H, W)

    # (4, 1, T, H, W)
    tof_conv = torch.zeros(4, 1, T, H, W).to(device)
    tof_conv[1, :] = conv2d(tof_Tx1xHxW, KK[1]).transpose(0, 1).reshape(1, 1, -1, H, W)
    tof_conv[2, :] = conv2d(tof_Tx1xHxW, KK[2]).transpose(0, 1).reshape(1, 1, -1, H, W)
    tof_conv[3, :] = conv2d(tof_Tx1xHxW, KK[3]).transpose(0, 1).reshape(1, 1, -1, H, W)
    tof_conv[0, 0, :] = tof_Tx1xHxW.squeeze(1)
    # tof_conv[0, 0, :, :, :] = torch.transpose(tof_NxT, 0, 1).reshape(T, H, W).to(device)
    del tof_Tx1xHxW, tof_NxT # tof_conv2d
    # depths = torch.zeros(nscale, H, W)
    # depths = depths.cuda()
    # depths[0:4, :, :] = torch.argmax(tof_conv, dim=2).squeeze()
    
    d0 = torch.argmax(tof_conv, dim=2).squeeze().cpu()
    print("4 scales completed. 8 additional scales are generated by separable 3d convolution.")
    #----------------- 3. 3D conv to generate two other sets 
    if use_cuda:
        if nscale >= 8:
            d1 = torch.argmax(conv3d_separate(tof_conv, KK[-2]), dim=2).squeeze().cpu()

        if nscale >= 12:
            d2 = torch.argmax(conv3d_separate(tof_conv, KK[-1]), dim=2).squeeze().cpu()

        del tof_conv

    else:
        if nscale >= 8:
            d1 = torch.argmax(conv3d_separate_cpu(tof_conv, KK[-2]), dim=2).squeeze()

        if nscale >= 12:
            d2 = torch.argmax(conv3d_separate_cpu(tof_conv, KK[-1]), dim=2).squeeze()

        del tof_conv

    depths = torch.cat([d0, d1, d2], dim=0)
    del d0, d1, d2
    if use_cuda:
        depths = depths.cuda()

    # add 1 to be consistent with Julia and normalize wrt. T as a preprocessing
    depths = (depths + 1.0) / T
    return depths

if __name__ == "__main__":
    import time
    tof_cpu = torch.zeros([4, 1, 1024, 500, 500])
    tof = tof_cpu.cuda()
    a = torch.argmax(conv3d_separate(tof, 5), dim=2)
    t0 = time.time()
    a = torch.argmax(conv3d_separate(tof, 5), dim=2)
    print(time.time() - t0)

    # t0 = time.time()
    # a = torch.argmax(conv3d_separate(tof_cpu, 5), dim=2)
    # print(time.time() - t0)